let formularioDatos = document.getElementById('formDatos');

const entregarDatos = (event) => {
    event.preventDefault();
    let datos = new FormData(formularioDatos);
    axios({
        method: 'post',
        url: 'http://localhost/izipayapi/public/Charge/CreatePayment',
        responseType: 'json',
        data: {
            amount : datos.get('amount'),
            currency : datos.get('currency'),
            customer : {
                email : datos.get('email')    
            },
            orderId : datos.get('orderId')
        }
    })
        .then(function (response) {
          console.log(response.data);
    });

}

//export dafault App;
<?php
 
$app->get('/', function($request, $response, array $args){
    echo "Inicio";
    return $response;
});	

?>
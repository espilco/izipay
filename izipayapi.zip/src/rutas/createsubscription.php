<?php
$app->post('/Charge/CreateSubscription', function($request, $response, array $args){
    $contents = json_decode(file_get_contents('php://input'), true);

    $url = 'https://api.micuentaweb.pe/api-payment/V4/Charge/CreateSubscription';
    
    $ch = curl_init($url);

    $jsonData = array(
        'amount' => $contents['amount'],
        'currency' => $contents['currency'],
        'effectDate' => $contents['effectDate'],
        'initialAmount' => $contents['initialAmount'],
        'initialAmountNumber' => $contents['initialAmountNumber'],
        'orderId' => $contents['orderId'],
        'rrule' => $contents['rrule']
    );

    $headers = array(
            'Content-type:application/json',
            'Authorization:Basic NTE0NDczNzg6dGVzdHBhc3N3b3JkXzZBZnN6cktnVVVNbXd1eGtZTTU0b0s3RlJKdU1JVEE5NHloYlFORmtuZGswMw=='
        );
    $jsonDataEncoded = json_encode($jsonData);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    echo $result;

    return $response;
});
?>
<?php
$app->post('/Charge/CreatePayment', function($request, $response, array $args){
    //$data = json_decode($request->getBody()) ?: $request->params();
    $contents = json_decode(file_get_contents('php://input'), true);

    //url de la petición
    $url = 'https://api.micuentaweb.pe/api-payment/V4/Charge/CreatePayment';
    
    //inicializamos el objeto CUrl
    $ch = curl_init($url);
    
    //armamos petición
    $jsonData = array(
        'amount' => (integer)$contents['amount'],
        'currency' => (string)$contents['currency'],
        'customer' => array(
            'email' => (string)$contents['customer']['email']
        ),
        'orderId' => (string)$contents['orderId']
    );

    $headers = array(
        'Content-type:application/json',
        'Authorization:Basic NTE0NDczNzg6dGVzdHBhc3N3b3JkXzZBZnN6cktnVVVNbXd1eGtZTTU0b0s3RlJKdU1JVEE5NHloYlFORmtuZGswMw=='
    );
 
    //creamos el json a partir de nuestro arreglo
    $jsonDataEncoded = json_encode($jsonData);
    
    //Indicamos que nuestra petición sera Post
    curl_setopt($ch, CURLOPT_POST, 1);
    
    //para que la peticion no imprima el resultado como un echo comun, y podamos manipularlo
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    
    //Adjuntamos el json a nuestra petición
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
    
    //Agregamos los encabezados del contenido
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    //ignorar el certificado, servidor de desarrollo
    //utilicen estas dos lineas si su petición es tipo https y estan en servidor de desarrollo
    //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    //curl_setopt($process, CURLOPT_SSL_VERIFYHOST, FALSE);
    
    //Ejecutamos la petición
    $result = curl_exec($ch);

    echo $result;
    
    return $response;
});

?>